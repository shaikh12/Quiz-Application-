package com.infodart.quizapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.infodart.quizapp.Model_Classes.Questions;
import com.infodart.quizapp.R;
import com.infodart.quizapp.SQLite.QuizDbHelper;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class Quiz_Activity extends AppCompatActivity {

    public static final String EXTRA_SCORE = "extraScore";

    private TextView textview_tot_score;
    private TextView textview_questions_countdown;
    private TextView textview_timer;
    private TextView textView_questions;
    private RadioGroup radioGroup;
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private RadioButton radioButton3;
    private RadioButton radioButton4;
    private Button btn_confirm;

    private List<Questions> questionsList;

    private ColorStateList colorStateList;
    private int questionCounter;
    private int questionCountTotal;
    private Questions currentQuestion;
    private int score;
    private boolean answered;
    private TextView textView_correct_ans;

    private long backPressedTime;
    private static final long COUNTDOWN_IN_MILLIS = 30000;
    private ColorStateList colorStateList_timer;
    private CountDownTimer countDownTimer;
    private long timeLeftInMillis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_);

        textview_tot_score = findViewById(R.id.textview_tot_score);
        textview_questions_countdown = findViewById(R.id.textview_questions_countdown);
        textview_timer = findViewById(R.id.textview_timer);
        textView_questions = findViewById(R.id.textview_questions);
        radioGroup = findViewById(R.id.radioGroup);
        radioButton1 = findViewById(R.id.radioButton1);
        radioButton2 = findViewById(R.id.radioButton2);
        radioButton3 = findViewById(R.id.radioButton3);
        radioButton4 = findViewById(R.id.radioButton4);
        btn_confirm = findViewById(R.id.btn_confirm);

        QuizDbHelper dbHelper = new QuizDbHelper(this);
        questionsList = dbHelper.getAllQuestions();

        colorStateList = radioButton1.getTextColors();
        questionCountTotal = questionsList.size();
        Collections.shuffle(questionsList);

        ShowNextQuestion();

        textView_correct_ans = findViewById(R.id.textview_correct_ans);
        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!answered){
                    if (radioButton1.isChecked() || radioButton2.isChecked() || radioButton3.isChecked() || radioButton4.isChecked()){
                        checkAnswer();
                    }else{
                        Toast.makeText(Quiz_Activity.this, "Please select an answer", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    ShowNextQuestion();
                }
            }
        });

        colorStateList_timer = textview_timer.getTextColors();
    }

    private void checkAnswer() {
        answered = true;
        countDownTimer.cancel();

        RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
        int answerNr = radioGroup.indexOfChild(radioButton) + 1;

        if (answerNr == currentQuestion.getAnswerNr()){
            score++;
            textview_tot_score.setText("Score:" + score);
        }

        showsolution();
    }

    private void showsolution() {

        radioButton1.setTextColor(Color.RED);
        radioButton2.setTextColor(Color.RED);
        radioButton3.setTextColor(Color.RED);
        radioButton4.setTextColor(Color.RED);

        switch (currentQuestion.getAnswerNr()){
            case 1:
                radioButton1.setTextColor(Color.GREEN);
                textView_correct_ans.setText("Option 1 is Correct");
                break;
            case 2:
                radioButton2.setTextColor(Color.GREEN);
                textView_correct_ans.setText("Option 2 is Correct");
                break;

            case 3:
                radioButton3.setTextColor(Color.GREEN);
                textView_correct_ans.setText("Option 3 is Correct");
                break;

            case 4:
                radioButton4.setTextColor(Color.GREEN);
                textView_correct_ans.setText("Option 4 is Correct");
                break;
        }

        if (questionCounter < questionCountTotal){
            btn_confirm.setText("Next");
        }else{
            btn_confirm.setText("Finish");
        }
    }

    private void ShowNextQuestion(){
        radioButton1.setTextColor(colorStateList);
        radioButton2.setTextColor(colorStateList);
        radioButton3.setTextColor(colorStateList);
        radioButton4.setTextColor(colorStateList);

        radioGroup.clearCheck();

        if (questionCounter < questionCountTotal){

            currentQuestion = questionsList.get(questionCounter);

            textView_questions.setText(currentQuestion.getQuestions());
            radioButton1.setText(currentQuestion.getOption1());
            radioButton2.setText(currentQuestion.getOption2());
            radioButton3.setText(currentQuestion.getOption3());
            radioButton4.setText(currentQuestion.getOption4());

            questionCounter++;
            textview_questions_countdown.setText("Questions "+ questionCounter + "/" + questionCountTotal);

            answered = false;
            btn_confirm.setText("Confirm");

            timeLeftInMillis = COUNTDOWN_IN_MILLIS;
            startCountDown();
        }else{
            finishQuiz();
        }
    }

    private void startCountDown() {
        countDownTimer = new CountDownTimer(timeLeftInMillis,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }
            @Override
            public void onFinish() {
                timeLeftInMillis = 0;
                updateCountDownText();
                checkAnswer();
            }
        }.start();
    }

    //CountDown Timer Method
    private void updateCountDownText() {
        int minutes =(int) (timeLeftInMillis/1000)/60;
        int seconds = (int) (timeLeftInMillis/1000)% 60;
        String timeFormatted = String.format(Locale.getDefault(),"%02d:%02d",minutes,seconds);
        textview_timer.setText(timeFormatted);

        if (timeLeftInMillis <10000){
            textview_timer.setTextColor(Color.RED);
        }else {
            textview_timer.setTextColor(colorStateList_timer);
        }
    }

    private void finishQuiz() {
        Intent resultIntent = new Intent();
        resultIntent.putExtra(EXTRA_SCORE,score);
        setResult(RESULT_OK,resultIntent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            finishQuiz();
        }else {
            Toast.makeText(this, "Press back again to finish", Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(countDownTimer != null){
            countDownTimer.cancel();
        }
    }
}
