package com.infodart.quizapp.SQLite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import com.infodart.quizapp.Model_Classes.Questions;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper implements BaseColumns {

    private static final String DATABASE_NAME = "quiz.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "quiz_questions";
    public static final String COLUMN_QUESTION = "question";
    public static final String COLUMN_OPTION1 = "option1";
    public static final String COLUMN_OPTION2 = "option2";
    public static final String COLUMN_OPTION3 = "option3";
    public static final String COLUMN_OPTION4 = "option4";
    public static final String COLUMN_ANSWER_NR = "answer_nr";
    private SQLiteDatabase db;

    public QuizDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //THIS METHOD IS USED TO access THE Database for the first time
        this.db = db;

        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE "+
                TABLE_NAME + " ( " +
                _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_QUESTION + " TEXT, " +
                COLUMN_OPTION1 + " TEXT, " +
                COLUMN_OPTION2 + " TEXT, " +
                COLUMN_OPTION3 + " TEXT, " +
                COLUMN_OPTION4 + " TEXT, " +
                COLUMN_ANSWER_NR + " INTEGER " + ")";

        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME );
        onCreate(db);
    }

    private void fillQuestionsTable() {

        //  DUMMY DATA
        Questions q1 = new Questions("Full form of .dex file", "Dalvik Executable file","Dex file","Executable file","None of the above",1);
        addQuestions(q1);
        Questions q2 = new Questions("Full form of ADB", "Application bridge","Android debug bridge","Async debug bridge","None of the above",2);
        addQuestions(q2);
        Questions q3 = new Questions("Ful form od DDMS", "Monitoring Service","Debug Dalvik Monitoring Service","Dalvik Debug Monitor Service","Dalvik Distance Manager Service",3);
        addQuestions(q3);
        Questions q4 = new Questions("Full form of ADK", "Android Development Kit","Application Development Kit","Android Development Key","Application Development Key",1);
        addQuestions(q4);
        Questions q5 = new Questions("Full form of AOSP", " Application Open System Project","Android Online System Profile","Application Open Source Project"," Android Open System Project",4);
        addQuestions(q5);
        Questions q6 = new Questions("Latest version of Android is - ", "Pie","Oreo","Nougat","10.0",4);
        addQuestions(q6);
        Questions q7 = new Questions(" What is the difference between margin and padding in android layout?", "Margin is specifying the extra space left on all four sides in layout","Padding is used to offset the content of a view by specific px or dp","Both 1 & 2 are correct","None of the above",3);
        addQuestions(q7);
        Questions q8 = new Questions("How many threads are there in asyncTask in android?", "Only one","Two","Async task doesn't have thread","None of the above",1);
        addQuestions(q8);
        Questions q9 = new Questions("What is the time limit of broadcast receiver in android?", "15 sec","10 sec","5 sec","1 hour",2);
        addQuestions(q9);
        Questions q10 = new Questions("What is the library of Map View in android?", "com.goggle.android.maps","in.maps","com.goggle.gogglemaps"," com.map",1);
        addQuestions(q10);
    }

    private void addQuestions(Questions questions){
        ContentValues cv = new ContentValues();
        /*
        ContentValue class lets you put information inside an object in the form of
        Key-Value pairs for columns and their value. The object can then be passed
        to the insert() method of an instance of the SQLiteDatabase class
         to insert or update your WritableDatabase.
         */
        cv.put(COLUMN_QUESTION,questions.getQuestions());
        cv.put(COLUMN_OPTION1,questions.getOption1());
        cv.put(COLUMN_OPTION2,questions.getOption2());
        cv.put(COLUMN_OPTION3,questions.getOption3());
        cv.put(COLUMN_OPTION4,questions.getOption4());
        cv.put(COLUMN_ANSWER_NR,questions.getAnswerNr());

        db.insert(TABLE_NAME,null,cv);
    }

    public List<Questions> getAllQuestions(){

        // This method is used to RETRIEVE THE DATA and to ACCESS it from Another Class.

        List<Questions> questionsList = new ArrayList<>();
        db = this.getReadableDatabase();// this method will call the database from onCreate Method

        /*Cursors are what contain the result set of a query made against a database
        in Android. The Cursor class has an API that allows an app to read the columns
        that were returned from the query as well as iterate over the rows
        of the result set*/

        Cursor c = db.rawQuery("SELECT * FROM " +TABLE_NAME,
                null);

        if (c.moveToFirst()){ // move the cursor to the first entry if it exists
            do {
                Questions questions = new Questions();
                questions.setQuestions(c.getString(c.getColumnIndex(COLUMN_QUESTION)));
                questions.setOption1(c.getString(c.getColumnIndex(COLUMN_OPTION1)));
                questions.setOption2(c.getString(c.getColumnIndex(COLUMN_OPTION2)));
                questions.setOption3(c.getString(c.getColumnIndex(COLUMN_OPTION3)));
                questions.setOption4(c.getString(c.getColumnIndex(COLUMN_OPTION4)));
                questions.setAnswerNr(c.getInt(c.getColumnIndex(COLUMN_ANSWER_NR)));

                questionsList.add(questions);

            }while (c.moveToNext());
        }
        c.close();
        return questionsList;
    }
}
